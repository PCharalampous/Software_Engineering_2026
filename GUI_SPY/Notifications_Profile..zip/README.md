# FlatmateApp – JavaFX GUI Mock-up

## Υλοποιημένα Use Cases
- **Use Case 5**  – Notifications
- **Use Case 10** – Profile Management

## Κλάσεις (από Sequence Diagrams)

| Τύπος      | Κλάση                          |
|------------|-------------------------------|
| Entity     | `UserProfile`                 |
| Entity     | `Notification`                |
| Entity     | `FlatRequest`                 |
| Entity     | `UnreadCounter`               |
| Controller | `ManageProfileClass`          |
| Controller | `ManageNotificationsClass`    |
| View       | `ProfileScreen`               |
| View       | `EditProfileScreen`           |
| View       | `RequestsScreen`              |
| View       | `NotificationsScreen`         |
| View       | `NotificationDetailsScreen`   |
| View       | `ConfirmationScreen`          |
| View       | `ScreenWithOptionalJustification` |

---

## Τρέξιμο με Maven (συνιστάται)

```bash
# Απαιτεί: Java 21 + Maven
mvn javafx:run
```

## Εναλλακτικά – με JavaFX SDK

1. Κατέβασε το JavaFX SDK 21 από https://gluonhq.com/products/javafx/
2. Αντίγραψε το `FlatmateApp.java` στον φάκελο του SDK

```bash
# Compile
javac --module-path /path/to/javafx-sdk/lib \
      --add-modules javafx.controls \
      FlatmateApp.java

# Run
java --module-path /path/to/javafx-sdk/lib \
     --add-modules javafx.controls \
     FlatmateApp
```

---

## Λειτουργίες

### Profile (UC10)
- Εμφάνιση προφίλ (avatar, stats, bio, applications)
- Edit Profile με validation (κενό display name → INVALID INPUT)
- PROFILE UPDATED μετά από επιτυχή αποθήκευση
- Requests: INCOMING / OUTGOING tabs
- ACCEPT / DECLINE με ScreenWithOptionalJustification dialog
- Ανανέωση λίστας μετά από κάθε action

### Notifications (UC5)
- Λίστα ALL / UNREAD με μετρητή
- MARK ALL AS READ → μηδενισμός counter
- Κλικ σε ειδοποίηση → markAsRead() + NotificationDetailsScreen
- GO TO → navigation στην αντίστοιχη ενότητα
- DELETE → ConfirmationScreen (Confirm / Cancel)
