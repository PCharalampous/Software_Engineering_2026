package notifications;

import entities.Authentication;
import entities.Notification;
import entities.User;
import util.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class ApprovalRequestService {
    private static final String BILL_APPROVAL = "BILL_APPROVAL";
    private static final String ISSUE_APPROVAL = "ISSUE_APPROVAL";

    public static boolean hasApprovalRecipients(Connection conn, int roomId, int creatorId, String payers) throws SQLException {
        return !findPayerUserIds(conn, roomId, creatorId, payers).isEmpty();
    }

    public static int createBillApprovalRequests(Connection conn, int billId, int roomId, int creatorId,
                                                 String billType, double amount, String date, String payers) throws SQLException {
        List<Integer> recipientIds = findPayerUserIds(conn, roomId, creatorId, payers);
        String target = buildTarget(BILL_APPROVAL, billId, creatorId);
        String detail = "Ζητείται αποδοχή συμμετοχής στον λογαριασμό '" + billType + "' (" + amount + "€, " + date + "). Πληρωτές: " + payers;

        return insertApprovalNotifications(
            conn,
            recipientIds,
            roomId,
            "BILLS",
            "Αποδοχή λογαριασμού",
            detail,
            target,
            "#14B8A6"
        );
    }

    public static int createIssueApprovalRequests(Connection conn, int issueId, int roomId, int creatorId,
                                                  String issueType, String reportedBy, String date, String payers) throws SQLException {
        List<Integer> recipientIds = findPayerUserIds(conn, roomId, creatorId, payers);
        String target = buildTarget(ISSUE_APPROVAL, issueId, creatorId);
        String detail = "Ζητείται αποδοχή συμμετοχής στη βλάβη '" + issueType + "' που δήλωσε ο/η " + reportedBy + " (" + date + "). Πληρωτές: " + payers;

        return insertApprovalNotifications(
            conn,
            recipientIds,
            roomId,
            "ISSUES",
            "Αποδοχή βλάβης",
            detail,
            target,
            "#F97316"
        );
    }

    public static boolean isApprovalRequest(Notification notification) {
        return parseTarget(notification.getTarget()) != null;
    }

    public static String routeTargetFor(Notification notification) {
        ApprovalTarget target = parseTarget(notification.getTarget());
        if (target == null) {
            String rawTarget = notification.getTarget();
            if (rawTarget != null && rawTarget.startsWith("BILL")) return "BILLS_SCREEN";
            if (rawTarget != null && rawTarget.startsWith("ISSUE")) return "ISSUES_SCREEN";
            return rawTarget;
        }
        return target.kind.equals(BILL_APPROVAL) ? "BILLS_SCREEN" : "ISSUES_SCREEN";
    }

    public static String handleDecision(Notification notification, boolean approved) throws SQLException {
        ApprovalTarget target = parseTarget(notification.getTarget());
        if (target == null) return "This notification is not an approval request.";

        User currentUser = Authentication.getCurrentUser();
        String responderName = (currentUser != null) ? currentUser.getUsername() : "Κάποιος";

        try (Connection conn = DatabaseManager.getConnection()) {
            conn.setAutoCommit(false);
            try {
                String result;
                if (target.kind.equals(BILL_APPROVAL)) {
                    result = handleBillDecision(conn, notification, target, approved, responderName);
                } else {
                    result = handleIssueDecision(conn, notification, target, approved, responderName);
                }
                conn.commit();
                return result;
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    private static String handleBillDecision(Connection conn, Notification notification, ApprovalTarget target,
                                             boolean approved, String responderName) throws SQLException {
        BillApprovalDetails bill = loadBillDetails(conn, target.itemId);
        if (bill == null) {
            closeNotificationAsUnavailable(conn, notification, target, "Ο λογαριασμός δεν είναι πλέον διαθέσιμος.");
            return "Ο λογαριασμός δεν είναι πλέον διαθέσιμος.";
        }

        if (approved) {
            markNotificationDecision(conn, notification, target, "BILL_APPROVED", "Αποδέχτηκες τον λογαριασμό",
                "Αποδέχτηκες τη συμμετοχή σου στον λογαριασμό '" + bill.type + "'.", "#10B981");

            if (countPendingApprovals(conn, target.originalTarget) == 0) {
                notifyCreator(conn, target.creatorId, bill.roomId, "BILLS", "Ο λογαριασμός εγκρίθηκε",
                    "Όλοι οι επιλεγμένοι πληρωτές αποδέχτηκαν τον λογαριασμό '" + bill.type + "'.", "BILLS_SCREEN", "#10B981");
            }
            return "Η αποδοχή καταχωρήθηκε.";
        }

        cancelBill(conn, bill);
        cancelRemainingApprovalNotifications(conn, target, notification.getNotificationId(), "BILL_DECLINED",
            "Ακυρώθηκε λογαριασμός",
            "Ο/Η " + responderName + " απέρριψε τον λογαριασμό '" + bill.type + "'. Η προσθήκη ακυρώθηκε.",
            "#EF4444");
        markNotificationDecision(conn, notification, target, "BILL_DECLINED", "Απέρριψες τον λογαριασμό",
            "Απέρριψες τον λογαριασμό '" + bill.type + "'. Η προσθήκη ακυρώθηκε.", "#EF4444");
        notifyCreator(conn, target.creatorId, bill.roomId, "BILLS", "Απόρριψη λογαριασμού",
            "Ο/Η " + responderName + " απέρριψε τον λογαριασμό '" + bill.type + "'. Η διαδικασία προσθήκης ακυρώθηκε.",
            "BILLS_SCREEN", "#EF4444");
        return "Η απόρριψη καταχωρήθηκε και ο λογαριασμός ακυρώθηκε.";
    }

    private static String handleIssueDecision(Connection conn, Notification notification, ApprovalTarget target,
                                              boolean approved, String responderName) throws SQLException {
        IssueApprovalDetails issue = loadIssueDetails(conn, target.itemId);
        if (issue == null) {
            closeNotificationAsUnavailable(conn, notification, target, "Η βλάβη δεν είναι πλέον διαθέσιμη.");
            return "Η βλάβη δεν είναι πλέον διαθέσιμη.";
        }

        if (approved) {
            markNotificationDecision(conn, notification, target, "ISSUE_APPROVED", "Αποδέχτηκες τη βλάβη",
                "Αποδέχτηκες τη συμμετοχή σου στη βλάβη '" + issue.type + "'.", "#10B981");

            if (countPendingApprovals(conn, target.originalTarget) == 0) {
                updateIssueApprovalStatus(conn, target.itemId, "Accepted");
                notifyCreator(conn, target.creatorId, issue.roomId, "ISSUES", "Η βλάβη εγκρίθηκε",
                    "Όλοι οι επιλεγμένοι πληρωτές αποδέχτηκαν τη βλάβη '" + issue.type + "'.", "ISSUES_SCREEN", "#10B981");
            }
            return "Η αποδοχή καταχωρήθηκε.";
        }

        updateIssueApprovalStatus(conn, target.itemId, "Declined");
        cancelRemainingApprovalNotifications(conn, target, notification.getNotificationId(), "ISSUE_DECLINED",
            "Ακυρώθηκε βλάβη",
            "Ο/Η " + responderName + " απέρριψε τη βλάβη '" + issue.type + "'. Η προσθήκη ακυρώθηκε.",
            "#EF4444");
        markNotificationDecision(conn, notification, target, "ISSUE_DECLINED", "Απέρριψες τη βλάβη",
            "Απέρριψες τη βλάβη '" + issue.type + "'. Η προσθήκη ακυρώθηκε.", "#EF4444");
        notifyCreator(conn, target.creatorId, issue.roomId, "ISSUES", "Απόρριψη βλάβης",
            "Ο/Η " + responderName + " απέρριψε τη βλάβη '" + issue.type + "'. Η διαδικασία προσθήκης ακυρώθηκε.",
            "ISSUES_SCREEN", "#EF4444");
        return "Η απόρριψη καταχωρήθηκε και η βλάβη ακυρώθηκε.";
    }

    private static int insertApprovalNotifications(Connection conn, List<Integer> recipientIds, int roomId, String category,
                                                   String text, String detail, String target, String color) throws SQLException {
        if (recipientIds.isEmpty()) return 0;

        String sql = "INSERT INTO notifications (user_id, room_id, category, notification_text, detail, target_screen, tag_color) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        int inserted = 0;

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            for (int userId : recipientIds) {
                stmt.setInt(1, userId);
                stmt.setInt(2, roomId);
                stmt.setString(3, category);
                stmt.setString(4, text);
                stmt.setString(5, detail);
                stmt.setString(6, target);
                stmt.setString(7, color);
                stmt.addBatch();
                inserted++;
            }
            stmt.executeBatch();
        }

        return inserted;
    }

    private static List<Integer> findPayerUserIds(Connection conn, int roomId, int creatorId, String payers) throws SQLException {
        Set<Integer> userIds = new LinkedHashSet<>();
        if (payers == null || payers.trim().isEmpty()) return new ArrayList<>();

        if ("All Roommates".equalsIgnoreCase(payers.trim())) {
            String sql = "SELECT user_id FROM users WHERE room_id = ? AND user_id != ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, roomId);
                stmt.setInt(2, creatorId);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) userIds.add(rs.getInt("user_id"));
                }
            }
            return new ArrayList<>(userIds);
        }

        String sql = "SELECT user_id FROM users WHERE room_id = ? AND user_id != ? AND " +
                     "(TRIM(username) = ? OR TRIM(display_name) = ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            for (String rawName : payers.split(",")) {
                String name = rawName.trim();
                if (name.isEmpty()) continue;

                stmt.setInt(1, roomId);
                stmt.setInt(2, creatorId);
                stmt.setString(3, name);
                stmt.setString(4, name);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) userIds.add(rs.getInt("user_id"));
                }
            }
        }

        return new ArrayList<>(userIds);
    }

    private static BillApprovalDetails loadBillDetails(Connection conn, int billId) throws SQLException {
        String sql = "SELECT room_id, bill_type, amount, bill_date FROM bills WHERE bill_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, billId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new BillApprovalDetails(
                        billId,
                        rs.getInt("room_id"),
                        rs.getString("bill_type"),
                        rs.getDouble("amount"),
                        rs.getString("bill_date")
                    );
                }
            }
        }

        return null;
    }

    private static IssueApprovalDetails loadIssueDetails(Connection conn, int issueId) throws SQLException {
        String sql = "SELECT room_id, issue_type FROM issues WHERE issue_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, issueId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new IssueApprovalDetails(rs.getInt("room_id"), rs.getString("issue_type"));
                }
            }
        }

        return null;
    }

    private static int countPendingApprovals(Connection conn, String originalTarget) throws SQLException {
        String sql = "SELECT COUNT(*) FROM notifications WHERE target_screen = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, originalTarget);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }

        return 0;
    }

    private static void cancelBill(Connection conn, BillApprovalDetails bill) throws SQLException {
        String deleteBillSql = "DELETE FROM bills WHERE bill_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(deleteBillSql)) {
            stmt.setInt(1, bill.id);
            stmt.executeUpdate();
        }

        String deleteCalendarSql = "DELETE FROM calendar_events WHERE room_id = ? AND event_name = ? AND event_date = ?";
        try (PreparedStatement stmt = conn.prepareStatement(deleteCalendarSql)) {
            stmt.setInt(1, bill.roomId);
            stmt.setString(2, "Bill: " + bill.type);
            stmt.setString(3, bill.date);
            int deletedEvents = stmt.executeUpdate();
            if (deletedEvents > 0) {
                AppNotificationService.notifyRoomMembers(
                    conn,
                    bill.roomId,
                    "CALENDAR",
                    "Διαγραφή event",
                    "Ο/Η " + AppNotificationService.currentUsername() + " διέγραψε το BILL event 'Bill: " +
                        bill.type + "' στις " + bill.date + " επειδή απορρίφθηκε ο λογαριασμός.",
                    "CALENDAR_SCREEN",
                    "#06B6D4"
                );
            }
        }
    }

    private static void updateIssueApprovalStatus(Connection conn, int issueId, String status) throws SQLException {
        String sql = "UPDATE issues SET approval_status = ? WHERE issue_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, issueId);
            stmt.executeUpdate();
        }
    }

    private static void notifyCreator(Connection conn, int creatorId, int roomId, String category, String text,
                                      String detail, String targetScreen, String color) throws SQLException {
        User currentUser = Authentication.getCurrentUser();
        if (creatorId <= 0 || (currentUser != null && creatorId == currentUser.getId())) return;

        String sql = "INSERT INTO notifications (user_id, room_id, category, notification_text, detail, target_screen, tag_color) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, creatorId);
            stmt.setInt(2, roomId);
            stmt.setString(3, category);
            stmt.setString(4, text);
            stmt.setString(5, detail);
            stmt.setString(6, targetScreen);
            stmt.setString(7, color);
            stmt.executeUpdate();
        }
    }

    private static void markNotificationDecision(Connection conn, Notification notification, ApprovalTarget target,
                                                 String statusPrefix, String text, String detail, String color) throws SQLException {
        String sql = "UPDATE notifications SET target_screen = ?, notification_text = ?, detail = ?, tag_color = ?, is_read = TRUE " +
                     "WHERE notification_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, buildTarget(statusPrefix, target.itemId, target.creatorId));
            stmt.setString(2, text);
            stmt.setString(3, detail);
            stmt.setString(4, color);
            stmt.setInt(5, notification.getNotificationId());
            stmt.executeUpdate();
        }
    }

    private static void cancelRemainingApprovalNotifications(Connection conn, ApprovalTarget target, int currentNotificationId,
                                                             String statusPrefix, String text, String detail, String color) throws SQLException {
        String sql = "UPDATE notifications SET target_screen = ?, notification_text = ?, detail = ?, tag_color = ?, is_read = FALSE " +
                     "WHERE (target_screen = ? OR target_screen = ?) AND notification_id != ?";
        String approvedTarget = buildTarget(target.kind.equals(BILL_APPROVAL) ? "BILL_APPROVED" : "ISSUE_APPROVED", target.itemId, target.creatorId);
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, buildTarget(statusPrefix, target.itemId, target.creatorId));
            stmt.setString(2, text);
            stmt.setString(3, detail);
            stmt.setString(4, color);
            stmt.setString(5, target.originalTarget);
            stmt.setString(6, approvedTarget);
            stmt.setInt(7, currentNotificationId);
            stmt.executeUpdate();
        }
    }

    private static void closeNotificationAsUnavailable(Connection conn, Notification notification, ApprovalTarget target,
                                                       String detail) throws SQLException {
        markNotificationDecision(conn, notification, target, target.kind + "_UNAVAILABLE", "Μη διαθέσιμο αίτημα", detail, "#9CA3AF");
    }

    private static String buildTarget(String kind, int itemId, int creatorId) {
        return kind + ":" + itemId + ":" + creatorId;
    }

    private static ApprovalTarget parseTarget(String targetScreen) {
        if (targetScreen == null) return null;

        String[] parts = targetScreen.split(":");
        if (parts.length != 3) return null;
        if (!parts[0].equals(BILL_APPROVAL) && !parts[0].equals(ISSUE_APPROVAL)) return null;

        try {
            return new ApprovalTarget(parts[0], Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), targetScreen);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private static class ApprovalTarget {
        final String kind;
        final int itemId;
        final int creatorId;
        final String originalTarget;

        ApprovalTarget(String kind, int itemId, int creatorId, String originalTarget) {
            this.kind = kind;
            this.itemId = itemId;
            this.creatorId = creatorId;
            this.originalTarget = originalTarget;
        }
    }

    private static class BillApprovalDetails {
        final int id;
        final int roomId;
        final String type;
        final double amount;
        final String date;

        BillApprovalDetails(int id, int roomId, String type, double amount, String date) {
            this.id = id;
            this.roomId = roomId;
            this.type = type;
            this.amount = amount;
            this.date = date;
        }
    }

    private static class IssueApprovalDetails {
        final int roomId;
        final String type;

        IssueApprovalDetails(int roomId, String type) {
            this.roomId = roomId;
            this.type = type;
        }
    }
}
