package notifications;

import entities.Authentication;
import entities.User;
import util.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AppNotificationService {
    public static void notifyRoomMembers(String category, String text, String detail, String targetScreen, String tagColor) {
        User currentUser = Authentication.getCurrentUser();
        int roomId = (currentUser != null) ? currentUser.getRoomId() : 0;

        if (roomId <= 0) return;

        try (Connection conn = DatabaseManager.getConnection()) {
            notifyRoomMembers(conn, roomId, category, text, detail, targetScreen, tagColor);
        } catch (SQLException e) {
            System.err.println("Notification insert failed:");
            e.printStackTrace();
        }
    }

    public static void notifyRoomMembers(Connection conn, int roomId, String category, String text, String detail,
                                         String targetScreen, String tagColor) throws SQLException {
        User currentUser = Authentication.getCurrentUser();
        int currentUserId = (currentUser != null) ? currentUser.getId() : -1;

        String sql =
            "INSERT INTO notifications (user_id, room_id, category, notification_text, detail, target_screen, tag_color) " +
            "SELECT user_id, ?, ?, ?, ?, ?, ? " +
            "FROM users WHERE room_id = ? AND user_id != ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, roomId);
            stmt.setString(2, category);
            stmt.setString(3, text);
            stmt.setString(4, detail);
            stmt.setString(5, targetScreen);
            stmt.setString(6, tagColor);
            stmt.setInt(7, roomId);
            stmt.setInt(8, currentUserId);
            stmt.executeUpdate();
        }
    }

    public static String currentUsername() {
        User currentUser = Authentication.getCurrentUser();
        return (currentUser != null) ? currentUser.getUsername() : "Κάποιος";
    }
}
