package chores;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import util.DatabaseManager;

public class ChoreDistributionService {

    private final int roomId;
    private final List<String> members;

    public ChoreDistributionService(int roomId, List<String> members) {
        this.roomId = roomId;
        this.members = members;
    }

    public boolean distributeWeeklyChores() {
        if (members == null || members.isEmpty() || roomId == 0) return false;

        try (Connection conn = DatabaseManager.getConnection()) {

            // Έλεγχος αν υπάρχει έστω μία δουλειά που είναι ακόμη ανατεθειμένη σε κάποιον.
            String checkPendingSql = "SELECT COUNT(*) FROM chores WHERE room_id = ? AND assignee != 'Unassigned'";
            
            boolean dynamicProceed = true;
            
            try (PreparedStatement psCheck = conn.prepareStatement(checkPendingSql)) {
                psCheck.setInt(1, roomId);
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        dynamicProceed = false;
                    }
                }
            }

            if (!dynamicProceed) {
                System.out.println("Cannot shuffle! There are still assigned chores.");
                
                javafx.application.Platform.runLater(() -> {
                    Alert alert = new Alert(
                        Alert.AlertType.WARNING,
                        "Cannot redistribute! All chores must be 'Unassigned' before starting a new round.",
                        ButtonType.OK
                    );
                    alert.setHeaderText("Redistribution Blocked");
                    alert.showAndWait();
                });
                
                return false;
            }

            // 2. Μάζεψε όλα τα διαθέσιμα Chore IDs του δωματίου
            List<Integer> choreIds = new ArrayList<>();
            String getChoresSql = "SELECT chore_id FROM chores WHERE room_id = ?";
            try (PreparedStatement psGet = conn.prepareStatement(getChoresSql)) {
                psGet.setInt(1, roomId);
                try (ResultSet rs = psGet.executeQuery()) {
                    while (rs.next()) choreIds.add(rs.getInt("chore_id"));
                }
            }

            if (choreIds.isEmpty()) {
                System.out.println("No chores to distribute for room: " + roomId);
                javafx.application.Platform.runLater(() -> {
                    Alert alert = new Alert(
                        Alert.AlertType.INFORMATION,
                        "No chores found! Please add chores first using the '+' button.",
                        ButtonType.OK
                    );
                    alert.setHeaderText("No Chores Available");
                    alert.showAndWait();
                });
                return false;
            }

            conn.setAutoCommit(false);

            String updateChoreSql = "UPDATE chores SET assignee = ?, chore_status = 'Pending', approve_votes = 0, reject_votes = 0 WHERE chore_id = ?";
            
            // Καθαρισμός όλων των παλιών ψήφων του δωματίου.
            String deleteVotesSql = "DELETE FROM chore_reports WHERE room_id = ? AND description = 'Chore Vote Log'";
            
            try (PreparedStatement psDelVotes = conn.prepareStatement(deleteVotesSql)) {
                psDelVotes.setInt(1, roomId);
                psDelVotes.executeUpdate();
                System.out.println("[HOMY DB] All old chore votes cleared from database reports for room: " + roomId);
            }
            
            List<String> shuffledMembers = new ArrayList<>(members);
            Collections.shuffle(shuffledMembers);

            int memberIndex = 0;
            try (PreparedStatement psUpdate = conn.prepareStatement(updateChoreSql)) {

                for (int choreId : choreIds) {
                    String assignedMember = shuffledMembers.get(memberIndex);

                    psUpdate.setString(1, assignedMember);
                    psUpdate.setInt(2, choreId);
                    psUpdate.addBatch();

                    memberIndex = (memberIndex + 1) % shuffledMembers.size();
                }

                psUpdate.executeBatch();
                conn.commit();
                System.out.println("Chores successfully redistributed among real house members!");
                return true;
            } catch (Exception ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
