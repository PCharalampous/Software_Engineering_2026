package debug;

import util.DatabaseManager;

public class DBDebugPrinter {
    public static void print(String table) {
        try {
            DatabaseManager db = new DatabaseManager();
            db.showTable(table);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
