package profile;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import entities.Request;
import entities.UserProfile;
import util.DatabaseManager;
import java.sql.ResultSet;

public class ManageProfileClass {
    private UserProfile currentUser;
    private List<Request> incomingRequests;

    public ManageProfileClass(UserProfile user, List<Request> requests) {
        this.currentUser = user;
        this.incomingRequests = requests;
    }

    public UserProfile queryProfile() { return currentUser; }

    public boolean validateChanges(String name) {
        return name != null && !name.trim().isEmpty();
    }

    public void save(String name, String bio, String prefs) {
        currentUser.name = (name != null) ? name.trim() : "";
        currentUser.bio = (bio != null) ? bio.trim() : "";
        currentUser.preferences = (prefs != null) ? prefs.trim() : "";

        String sql = "UPDATE users SET display_name = ?, bio = ?, preferences = ? WHERE user_id = ?";
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, currentUser.name);
            stmt.setString(2, currentUser.bio);
            stmt.setString(3, currentUser.preferences);
            stmt.setInt(4, currentUser.user_id);
            stmt.executeUpdate();
            System.out.println("Profile updated στη βάση για user_id: " + currentUser.user_id);

        } catch (SQLException e) {
            System.err.println("Σφάλμα κατά το update του profile:");
            e.printStackTrace();
        }
    }

    public void choseACCEPT(Request req, String justification) {
        // 1. Ενημερώνουμε την κατάσταση του αιτήματος σε 'ACCEPTED'
        String sqlRequest = "UPDATE room_requests SET request_status = 'ACCEPTED', justification = ? WHERE request_id = ?";
        
        // 2. Ενημερώνουμε τον αποστολέα να μπει στο δωμάτιο του Owner
        String sqlSender = "UPDATE users SET room_id = ? WHERE user_id = (SELECT sender_id FROM room_requests WHERE request_id = ?)";
        
        // 3. Εξασφαλίζουμε ότι ο Owner έχει το σωστό room_id στη βάση
        String sqlOwner = "UPDATE users SET room_id = ? WHERE user_id = ?";
        
        // 4. ΠΡΟΣΘΗΚΗ: Μειώνουμε τις κενές θέσεις (roommates_wanted) στην αγγελία του Owner
        String sqlDecreaseApps = "UPDATE applications SET roommates_wanted = roommates_wanted - 1 WHERE user_id = ? AND roommates_wanted > 0";

        try (Connection conn = DatabaseManager.getConnection()) {
            conn.setAutoCommit(false); // Χρήση Transaction για ACID ασφάλεια

            try (PreparedStatement stmt1 = conn.prepareStatement(sqlRequest);
                 PreparedStatement stmt2 = conn.prepareStatement(sqlSender);
                 PreparedStatement stmt3 = conn.prepareStatement(sqlOwner);
                 PreparedStatement stmt4 = conn.prepareStatement(sqlDecreaseApps)) {
                RequestDetails requestDetails = loadRequestDetails(conn, req.request_id);

                // Update Request
                stmt1.setString(1, justification);
                stmt1.setInt(2, req.request_id);
                stmt1.executeUpdate();

                // Update Sender
                stmt2.setInt(1, this.currentUser.room_id);
                stmt2.setInt(2, req.request_id);
                stmt2.executeUpdate();

                // Update Owner
                stmt3.setInt(1, this.currentUser.room_id);
                stmt3.setInt(2, this.currentUser.user_id);
                stmt3.executeUpdate();
                
                // Update Applications (Μείωση θέσης αγγελίας)
                stmt4.setInt(1, this.currentUser.user_id);
                stmt4.executeUpdate();

                notifyRequestAccepted(conn, requestDetails, justification);

                conn.commit();
                incomingRequests.remove(req);
                System.out.println("Το room_id ενημερώθηκε και οι ζητούμενοι συγκατοίκοι μειώθηκαν!");
                
                main.HOMYApp.showCentralHub();

            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException e) {
            System.err.println("Σφάλμα κατά την αποδοχή της αίτησης:");
            e.printStackTrace();
        }
    }

    public void choseDECLINE(Request req, String justification) {
        String sql = "UPDATE room_requests SET request_status = 'DECLINED', justification = ? WHERE request_id = ?";

        try (Connection conn = DatabaseManager.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                RequestDetails requestDetails = loadRequestDetails(conn, req.request_id);

                String cleanJustification = (justification == null) ? "" : justification.trim();
                stmt.setString(1, cleanJustification.isEmpty() ? null : cleanJustification);
                stmt.setInt(2, req.request_id);
                stmt.executeUpdate();

                notifyRequestDeclined(conn, requestDetails, justification);

                conn.commit();
                incomingRequests.remove(req);
            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            }
        } catch (SQLException e) {
            System.err.println("Σφάλμα κατά την απόρριψη της αίτησης:");
            e.printStackTrace();
        }
    }

    private void updateRequestStatus(int requestId, String status, String justification) {
        String sql = "UPDATE room_requests SET request_status = ?, justification = ? WHERE request_id = ?";
        try (Connection conn = DatabaseManager.getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setString(2, justification.trim().isEmpty() ? null : justification.trim());
            stmt.setInt(3, requestId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static UserProfile loadFromDatabase(int userId) {
        String sql = 
            "SELECT u.user_id, u.display_name, u.username, u.bio, u.preferences, u.room_id, " +
            "       COALESCE(up.current_balance, 0) AS points, " +
            "       COALESCE(r.room_flat_name, 'N/A') AS flat_name, " +
            "       COALESCE((SELECT COUNT(*) FROM users u2 WHERE u2.room_id = u.room_id), 0) AS members " +
            "FROM users u " +
            "LEFT JOIN user_points up ON up.user_id = u.user_id " +
            "LEFT JOIN rooms r ON r.room_id = u.room_id " +
            "WHERE u.user_id = ?";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new UserProfile(
                    rs.getInt("user_id"),
                    rs.getString("display_name"),
                    rs.getString("username"),
                    rs.getString("bio"),
                    rs.getString("preferences"),
                    rs.getInt("points"),
                    rs.getString("flat_name"),
                    rs.getInt("members"),
                    rs.getInt("room_id")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Request> loadRequestsFromDatabase(int roomId) {
        List<Request> requests = new ArrayList<>();
        String sql = 
            "SELECT rr.request_id, u.display_name, u.username, rr.request_time " +
            "FROM room_requests rr " +
            "JOIN users u ON u.user_id = rr.sender_id " +
            "WHERE rr.room_id = ? AND rr.request_status = 'PENDING'";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, roomId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String name = rs.getString("display_name");
                String[] parts = name.split(" ");
                String initials = parts.length >= 2
                    ? String.valueOf(parts[0].charAt(0)) + String.valueOf(parts[1].charAt(0))
                    : name.substring(0, Math.min(2, name.length()));

                requests.add(new Request(
                    rs.getInt("request_id"),
                    name,
                    initials.toUpperCase(),
                    rs.getString("request_time")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return requests;
    }

    private RequestDetails loadRequestDetails(Connection conn, int requestId) throws SQLException {
        String sql =
            "SELECT rr.room_id, rr.sender_id, " +
            "       COALESCE(NULLIF(TRIM(u.display_name), ''), u.username) AS sender_name, " +
            "       COALESCE(r.room_flat_name, 'το δωμάτιο') AS room_name " +
            "FROM room_requests rr " +
            "JOIN users u ON u.user_id = rr.sender_id " +
            "LEFT JOIN rooms r ON r.room_id = rr.room_id " +
            "WHERE rr.request_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new RequestDetails(
                        rs.getInt("room_id"),
                        rs.getInt("sender_id"),
                        rs.getString("sender_name"),
                        rs.getString("room_name")
                    );
                }
            }
        }

        return new RequestDetails(this.currentUser.room_id, -1, "Κάποιος", this.currentUser.flatName);
    }

    private void notifyRequestAccepted(Connection conn, RequestDetails request, String justification) throws SQLException {
        if (request.senderId <= 0) return;

        String senderSql =
            "INSERT INTO notifications (user_id, room_id, category, notification_text, detail, target_screen, tag_color) " +
            "VALUES (?, ?, 'REQUESTS', ?, ?, 'PROFILE_SCREEN', '#10B981')";

        try (PreparedStatement stmt = conn.prepareStatement(senderSql)) {
            stmt.setInt(1, request.senderId);
            stmt.setInt(2, request.roomId);
            stmt.setString(3, "Το αίτημά σου έγινε δεκτό");
            stmt.setString(4, buildDecisionDetail("Έγινες δεκτός/ή στο " + request.roomName + ".", justification));
            stmt.executeUpdate();
        }

        String roomUsersSql =
            "INSERT INTO notifications (user_id, room_id, category, notification_text, detail, target_screen, tag_color) " +
            "SELECT user_id, ?, 'ROOM', ?, ?, 'PROFILE_SCREEN', '#14B8A6' " +
            "FROM users WHERE room_id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(roomUsersSql)) {
            stmt.setInt(1, request.roomId);
            stmt.setString(2, "Νέο μέλος στο δωμάτιο");
            stmt.setString(3, "Ο/Η " + request.senderName + " έγινε δεκτός/ή στο " + request.roomName + ".");
            stmt.setInt(4, request.roomId);
            stmt.executeUpdate();
        }
    }

    private void notifyRequestDeclined(Connection conn, RequestDetails request, String justification) throws SQLException {
        if (request.senderId <= 0) return;

        String senderSql =
            "INSERT INTO notifications (user_id, room_id, category, notification_text, detail, target_screen, tag_color) " +
            "VALUES (?, ?, 'REQUESTS', ?, ?, 'PROFILE_SCREEN', '#EF4444')";

        try (PreparedStatement stmt = conn.prepareStatement(senderSql)) {
            stmt.setInt(1, request.senderId);
            stmt.setInt(2, request.roomId);
            stmt.setString(3, "Το αίτημά σου απορρίφθηκε");
            stmt.setString(4, buildDecisionDetail("Το αίτημά σου για το " + request.roomName + " απορρίφθηκε.", justification));
            stmt.executeUpdate();
        }

        String roomUsersSql =
            "INSERT INTO notifications (user_id, room_id, category, notification_text, detail, target_screen, tag_color) " +
            "SELECT user_id, ?, 'REQUESTS', ?, ?, 'PROFILE_SCREEN', '#EF4444' " +
            "FROM users WHERE room_id = ? AND user_id != ?";

        try (PreparedStatement stmt = conn.prepareStatement(roomUsersSql)) {
            stmt.setInt(1, request.roomId);
            stmt.setString(2, "Απόρριψη αιτήματος");
            stmt.setString(3, "Το αίτημα του/της " + request.senderName + " για το " + request.roomName + " απορρίφθηκε.");
            stmt.setInt(4, request.roomId);
            stmt.setInt(5, this.currentUser.user_id);
            stmt.executeUpdate();
        }
    }

    private String buildDecisionDetail(String baseMessage, String justification) {
        String cleanJustification = (justification == null) ? "" : justification.trim();
        if (cleanJustification.isEmpty()) {
            return baseMessage;
        }

        return baseMessage + " Αιτιολόγηση: " + cleanJustification;
    }

    private static class RequestDetails {
        final int roomId;
        final int senderId;
        final String senderName;
        final String roomName;

        RequestDetails(int roomId, int senderId, String senderName, String roomName) {
            this.roomId = roomId;
            this.senderId = senderId;
            this.senderName = senderName;
            this.roomName = roomName;
        }
    }
}
